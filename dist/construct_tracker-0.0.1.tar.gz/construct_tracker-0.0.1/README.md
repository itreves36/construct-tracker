# construct-tracker
Track and measure constructs, concepts or categories in text documents


# Installation

```bash
pip install construct-tracker
```