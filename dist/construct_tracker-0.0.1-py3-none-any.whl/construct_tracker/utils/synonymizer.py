#!/usr/bin/env python3

import os


def sy(input_path, output_path, output_format="wav", output_bitrate="32k"):
    """ """
    # do something
    pass
    return


if __name__ == "__main__":
    import argparse

    # Create the parser
    parser = argparse.ArgumentParser(description="Convert all mp3 in input_dir to other format such as wav")
    # Add an argument
    parser.add_argument("--input_dir", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--output_format", type=str, default="wav")
    parser.add_argument("--output_bitrate", type=str, default="32k")

    # Parse the argument
    args = parser.parse_args()
    input_dir = args.input_dir
    output_dir = args.output_dir
    output_format = args.output_format
    output_bitrate = args.output_bitrate

    os.makedirs(output_dir, exist_ok=True)
